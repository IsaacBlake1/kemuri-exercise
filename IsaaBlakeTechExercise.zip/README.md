Kemuri Technical exercise

## Installation

-   Unzip the folder
-   run npm install to install front end dependencies

## Running the project

In the top directory, run:

### `npm start`

This runs the app in the development mode.<br />
Open [http://localhost:3000](http://localhost:3000) to view the client in the browser.
